<?php
require_once 'includes/config.php';
require_once 'includes/db.php';
require_once 'includes/auth.php';

// Wajib login
if (!isLoggedIn()) {
    jsonResponse(['success' => false, 'error' => 'Belum login']);
}

$user   = currentUser();
$uid    = $user['UserID'];
$fotoId = (int)($_POST['foto_id'] ?? 0);
$action = $_POST['action'] ?? '';

if (!$fotoId) {
    jsonResponse(['success' => false, 'error' => 'Foto tidak ditemukan']);
}

// ── LIKE ──────────────────────────────────────────────
if ($action === 'like') {
    $existing = queryOne(
        "SELECT LikeID FROM likefoto WHERE FotoID=? AND UserID=?",
        [$fotoId, $uid], 'ii'
    );
    if ($existing) {
        execute("DELETE FROM likefoto WHERE FotoID=? AND UserID=?", [$fotoId, $uid], 'ii');
        $liked = false;
    } else {
        insert("INSERT INTO likefoto (FotoID,UserID,TanggalLike) VALUES (?,?,CURDATE())", [$fotoId, $uid], 'ii');
        $liked = true;
    }
    $count = queryOne("SELECT COUNT(*) as c FROM likefoto WHERE FotoID=?", [$fotoId], 'i')['c'];
    jsonResponse(['success' => true, 'liked' => $liked, 'count' => (int)$count]);
}

// ── KIRIM KOMENTAR ────────────────────────────────────
if ($action === 'komentar') {
    $isi = trim($_POST['IsiKomentar'] ?? '');
    if (empty($isi)) {
        jsonResponse(['success' => false, 'error' => 'Komentar kosong']);
    }
    $kid = insert(
        "INSERT INTO komentarfoto (FotoID,UserID,IsiKomentar,TanggalKomentar) VALUES (?,?,?,CURDATE())",
        [$fotoId, $uid, $isi], 'iis'
    );
    jsonResponse([
        'success'         => true,
        'KomentarID'      => $kid,
        'IsiKomentar'     => $isi,
        'Username'        => $user['Username'],
        'NamaLengkap'     => $user['NamaLengkap'],
        'TanggalKomentar' => date('d M Y'),
    ]);
}

// ── HAPUS KOMENTAR ────────────────────────────────────
if ($action === 'hapus_komentar') {
    $kid = (int)($_POST['KomentarID'] ?? 0);
    $kom = queryOne("SELECT * FROM komentarfoto WHERE KomentarID=?", [$kid], 'i');
    if ($kom && $kom['UserID'] == $uid) {
        execute("DELETE FROM komentarfoto WHERE KomentarID=?", [$kid], 'i');
        jsonResponse(['success' => true]);
    }
    jsonResponse(['success' => false, 'error' => 'Tidak diizinkan']);
}

// ── EDIT KOMENTAR ─────────────────────────────────────
if ($action === 'edit_komentar') {
    $kid = (int)($_POST['KomentarID'] ?? 0);
    $isi = trim($_POST['IsiKomentar'] ?? '');
    $kom = queryOne("SELECT * FROM komentarfoto WHERE KomentarID=?", [$kid], 'i');
    if ($kom && $kom['UserID'] == $uid && !empty($isi)) {
        execute("UPDATE komentarfoto SET IsiKomentar=? WHERE KomentarID=?", [$isi, $kid], 'si');
        jsonResponse(['success' => true, 'IsiKomentar' => $isi]);
    }
    jsonResponse(['success' => false, 'error' => 'Tidak diizinkan']);
}

jsonResponse(['success' => false, 'error' => 'Action tidak dikenali']);