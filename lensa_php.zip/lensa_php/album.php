<?php
require_once 'includes/config.php';
require_once 'includes/db.php';
require_once 'includes/auth.php';

requireLogin();
$user = currentUser();
$uid  = $user['UserID'];
$id   = (int)($_GET['id'] ?? 0);

// Handle edit album
if (isPost() && isset($_POST['action']) && $_POST['action'] === 'edit_album') {
    verifyCsrf();
    $nama  = trim($_POST['NamaAlbum'] ?? '');
    $desk  = trim($_POST['Deskripsi'] ?? '');
    $akses = $_POST['Akses'] ?? 'publik';
    $alb   = queryOne("SELECT * FROM album WHERE AlbumID=? AND UserID=?", [$id,$uid], 'ii');
    if ($alb && !empty($nama)) {
        execute("UPDATE album SET NamaAlbum=?,Deskripsi=?,Akses=? WHERE AlbumID=?",
                [$nama,$desk,$akses,$id], 'sssi');
        flash('success','Album berhasil diperbarui!');
    }
    redirect('album.php?id='.$id);
}

$album = queryOne("
    SELECT a.*, u.Username, u.NamaLengkap
    FROM album a JOIN user u ON a.UserID=u.UserID
    WHERE a.AlbumID=?
", [$id], 'i');

if (!$album) { flash('error','Album tidak ditemukan'); redirect('dashboard.php'); }
if ($album['Akses'] === 'private' && $album['UserID'] != $uid) {
    flash('error','Album ini bersifat private'); redirect('home.php');
}

$fotos = queryAll("
    SELECT f.*, (SELECT COUNT(*) FROM likefoto WHERE FotoID=f.FotoID) as jmlLike
    FROM foto f WHERE f.AlbumID=? ORDER BY f.FotoID ASC
", [$id], 'i');

$pageTitle = e($album['NamaAlbum']) . ' — Lensa Bercerita';
require_once 'includes/header.php';
?>

<div class="album-wrap">

  <a href="<?= BASE_URL ?>/dashboard.php" class="foto-back" style="position:relative;top:auto;left:auto;background:transparent;border:1px solid var(--bk4);margin-bottom:20px;display:inline-flex">
    <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path stroke-linecap="round" stroke-width="2" d="M15 19l-7-7 7-7"/>
    </svg>
    Kembali
  </a>

  <div class="album-header">
    <div>
      <h1 class="album-title"><?= e($album['NamaAlbum']) ?></h1>
      <?php if ($album['Deskripsi']): ?>
        <p class="album-desc"><?= e($album['Deskripsi']) ?></p>
      <?php endif; ?>
      <div class="album-meta-bar">
        <span><?= e($album['Username']) ?></span>
        <span>·</span>
        <span><?= count($fotos) ?> foto</span>
        <span>·</span>
        <span class="<?= $album['Akses']==='publik'?'badge-pub':'badge-priv' ?>"
              style="padding:2px 8px;border-radius:10px;font-size:10px"><?= $album['Akses'] ?></span>
        <span>·</span>
        <span><?= date('d M Y', strtotime($album['TanggalDibuat'])) ?></span>
      </div>
    </div>

    <?php if ($album['UserID'] == $uid): ?>
      <div style="display:flex;gap:8px;flex-shrink:0">
        <button onclick="document.getElementById('edit-album-form').style.display = document.getElementById('edit-album-form').style.display==='none'?'block':'none'"
                class="btn-sm btn-o" style="border-radius:6px;font-size:12px;padding:7px 14px">Edit</button>
        <a href="<?= BASE_URL ?>/dashboard.php?hapus_album=<?= $id ?>"
           onclick="return confirm('Hapus album ini?')"
           class="btn-sm" style="background:var(--red);color:#fff;border-radius:6px;font-size:12px;padding:7px 14px;text-decoration:none">Hapus</a>
      </div>
    <?php endif; ?>
  </div>

  <?php if ($album['UserID'] == $uid): ?>
  <div id="edit-album-form" style="display:none;background:var(--bk2);border:1px solid var(--bk4);border-radius:8px;padding:16px;margin-bottom:20px">
    <form method="POST">
      <input type="hidden" name="csrf_token" value="<?= csrf() ?>">
      <input type="hidden" name="action" value="edit_album">
      <div class="two-col">
        <div class="fg">
          <label class="lbl">Nama Album *</label>
          <input class="finput" type="text" name="NamaAlbum" value="<?= e($album['NamaAlbum']) ?>" required>
        </div>
        <div class="fg">
          <label class="lbl">Akses</label>
          <select class="finput" name="Akses" style="cursor:pointer">
            <option value="publik" <?= $album['Akses']==='publik'?'selected':'' ?>>Publik</option>
            <option value="private" <?= $album['Akses']==='private'?'selected':'' ?>>Private</option>
          </select>
        </div>
      </div>
      <div class="fg">
        <label class="lbl">Deskripsi</label>
        <textarea class="finput" name="Deskripsi" rows="2"><?= e($album['Deskripsi']) ?></textarea>
      </div>
      <button type="submit" class="auth-btn" style="font-size:12px;padding:8px 18px">Simpan</button>
    </form>
  </div>
  <?php endif; ?>

  <?php if ($fotos): ?>
    <div class="disc-grid">
      <?php foreach ($fotos as $foto): ?>
        <a href="<?= BASE_URL ?>/foto.php?id=<?= $foto['FotoID'] ?>" class="disc-item" style="text-decoration:none">
          <div class="disc-img-wrap">
            <img src="<?= BASE_URL ?>/uploads/<?= e($foto['LokasiFile']) ?>" alt="<?= e($foto['JudulFoto']) ?>"
                 style="width:100%;height:100%;object-fit:cover">
            <div class="disc-overlay">
              <div class="disc-title"><?= e($foto['JudulFoto']) ?></div>
              <div class="disc-meta">
                <span><?= date('d M Y', strtotime($foto['TanggalUnggah'])) ?></span>
                <span>♥ <?= $foto['jmlLike'] ?></span>
              </div>
            </div>
          </div>
        </a>
      <?php endforeach; ?>
    </div>
  <?php else: ?>
    <div class="empty-state">
      <svg width="40" height="40" fill="none" stroke="currentColor" viewBox="0 0 24 24" style="opacity:.3;margin-bottom:12px">
        <path stroke-linecap="round" stroke-width="1.5" d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z"/>
      </svg>
      <p style="color:var(--wh3);font-family:sans-serif;font-size:13px">Album ini masih kosong.</p>
      <?php if ($album['UserID'] == $uid): ?>
        <a href="<?= BASE_URL ?>/upload.php" style="font-size:12px;color:var(--wh);font-family:sans-serif">Unggah foto →</a>
      <?php endif; ?>
    </div>
  <?php endif; ?>

</div>

<?php require_once 'includes/footer.php'; ?>
