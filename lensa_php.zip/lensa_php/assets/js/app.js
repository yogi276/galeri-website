// ── Nav dropdown ──────────────────────────────────────
function toggleNavDropdown(e) {
  e.stopPropagation();
  const dd = document.getElementById('nav-dropdown');
  if (dd) dd.classList.toggle('open');
  const hm = document.getElementById('ham-menu');
  if (hm) hm.classList.remove('open');
}

function toggleHamMenu(e) {
  e.stopPropagation();
  const hm = document.getElementById('ham-menu');
  if (hm) hm.classList.toggle('open');
  const dd = document.getElementById('nav-dropdown');
  if (dd) dd.classList.remove('open');
}

document.addEventListener('click', function(e) {
  const dd  = document.getElementById('nav-dropdown');
  const hm  = document.getElementById('ham-menu');
  const av  = document.querySelector('.nav-avatar');
  const ham = document.querySelector('.ham-wrap');
  if (dd && !av?.contains(e.target))  dd.classList.remove('open');
  if (hm && !ham?.contains(e.target)) hm.classList.remove('open');
});

// ── Flash auto-hide ───────────────────────────────────
document.addEventListener('DOMContentLoaded', function() {
  const flash = document.querySelector('.flash-success');
  if (flash) {
    setTimeout(() => {
      flash.style.transition = 'opacity .5s';
      flash.style.opacity = '0';
      setTimeout(() => flash.remove(), 500);
    }, 3000);
  }
});

// ── Show/hide password ────────────────────────────────
function showPass(id) {
  const el = document.getElementById(id);
  if (el) el.type = 'text';
}
function hidePass(id) {
  const el = document.getElementById(id);
  if (el) el.type = 'password';
}
