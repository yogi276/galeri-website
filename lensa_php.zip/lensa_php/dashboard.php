<?php
require_once 'includes/config.php';
require_once 'includes/db.php';
require_once 'includes/auth.php';

requireLogin();
$user   = currentUser();
$uid    = $user['UserID'];
$akses  = $_GET['akses'] ?? 'semua';
$tab    = $_GET['tab'] ?? 'fotos';
$pageTitle = 'Dashboard — Lensa Bercerita';

// Handle buat album
if (isPost() && isset($_POST['action']) && $_POST['action'] === 'buat_album') {
    verifyCsrf();
    $nama  = trim($_POST['NamaAlbum'] ?? '');
    $desk  = trim($_POST['Deskripsi'] ?? '');
    $aksesA = $_POST['Akses'] ?? 'publik';
    if (!empty($nama)) {
        insert("INSERT INTO album (NamaAlbum,Deskripsi,TanggalDibuat,UserID,Akses) VALUES (?,?,CURDATE(),?,?)",
               [$nama,$desk,$uid,$aksesA], 'ssis');
        flash('success', 'Album berhasil dibuat!');
    }
    redirect('dashboard.php?tab=albums');
}

// Handle hapus album
if (isset($_GET['hapus_album'])) {
    $aid = (int)$_GET['hapus_album'];
    $alb = queryOne("SELECT * FROM album WHERE AlbumID=? AND UserID=?", [$aid,$uid], 'ii');
    if ($alb) {
        execute("DELETE FROM album WHERE AlbumID=?", [$aid], 'i');
        flash('success', 'Album berhasil dihapus!');
    }
    redirect('dashboard.php?tab=albums');
}

// Stats
$totalFoto    = queryOne("SELECT COUNT(*) as c FROM foto WHERE UserID=?", [$uid], 'i')['c'];
$totalLike    = queryOne("SELECT COUNT(*) as c FROM likefoto lf JOIN foto f ON lf.FotoID=f.FotoID WHERE f.UserID=?", [$uid], 'i')['c'];
$totalPrivate = queryOne("SELECT COUNT(*) as c FROM foto WHERE UserID=? AND Akses='private'", [$uid], 'i')['c'];

// Fotos
$fotoSql = "SELECT f.*, (SELECT COUNT(*) FROM likefoto WHERE FotoID=f.FotoID) as jmlLike FROM foto f WHERE f.UserID=?";
$fotoParams = [$uid]; $fotoTypes = 'i';
if ($akses !== 'semua') { $fotoSql .= " AND f.Akses=?"; $fotoParams[]=$akses; $fotoTypes.='s'; }
$fotoSql .= " ORDER BY f.FotoID DESC";
$fotos = queryAll($fotoSql, $fotoParams, $fotoTypes);

// Albums
$albSql = "SELECT a.*, (SELECT COUNT(*) FROM foto WHERE AlbumID=a.AlbumID) as jmlFoto,
           (SELECT LokasiFile FROM foto WHERE AlbumID=a.AlbumID ORDER BY FotoID ASC LIMIT 1) as coverFile
           FROM album a WHERE a.UserID=?";
$albParams = [$uid]; $albTypes = 'i';
if ($akses !== 'semua') { $albSql .= " AND a.Akses=?"; $albParams[]=$akses; $albTypes.='s'; }
$albSql .= " ORDER BY a.AlbumID DESC";
$albums = queryAll($albSql, $albParams, $albTypes);

require_once 'includes/header.php';
?>

<div class="dash-wrap">

  <!-- Stats -->
  <div class="dash-stats">
    <div class="ds-item"><div class="ds-num"><?= $totalFoto ?></div><div class="ds-lbl">Foto</div></div>
    <div class="ds-item"><div class="ds-num"><?= $totalLike ?></div><div class="ds-lbl">Like</div></div>
    <div class="ds-item"><div class="ds-num"><?= $totalPrivate ?></div><div class="ds-lbl">Private</div></div>
  </div>

  <!-- Tabs -->
  <div class="tabs" id="dash-tabs">
    <button class="tab-btn <?= $tab==='fotos'?'act':'' ?>" data-tab="fotos">Foto</button>
    <button class="tab-btn <?= $tab==='albums'?'act':'' ?>" data-tab="albums">Album</button>
  </div>

  <!-- TAB FOTO -->
  <div class="tab-content <?= $tab==='fotos'?'act':'' ?>" id="tab-fotos">
    <div class="dash-filter-bar">
      <a href="?tab=fotos&akses=semua" class="dash-filter-btn <?= $akses==='semua'?'act':'' ?>">Semua</a>
      <a href="?tab=fotos&akses=publik" class="dash-filter-btn <?= $akses==='publik'?'act':'' ?>">Publik</a>
      <a href="?tab=fotos&akses=private" class="dash-filter-btn <?= $akses==='private'?'act':'' ?>">Private</a>
    </div>
    <a href="<?= BASE_URL ?>/upload.php" class="dash-upload-btn" style="text-decoration:none">
      <svg width="14" height="14" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path stroke-linecap="round" stroke-width="2" d="M12 4v16m8-8H4"/>
      </svg>
      Unggah Foto
    </a>
    <div class="dash-grid">
      <?php if ($fotos): ?>
        <?php foreach ($fotos as $foto): ?>
          <div class="dash-photo">
            <a href="<?= BASE_URL ?>/foto.php?id=<?= $foto['FotoID'] ?>&from=dashboard" style="display:block;text-decoration:none">
              <div class="dash-photo-img">
                <img src="<?= BASE_URL ?>/uploads/<?= e($foto['LokasiFile']) ?>" alt="<?= e($foto['JudulFoto']) ?>"
                     style="width:100%;height:100%;object-fit:cover">
              </div>
            </a>
            <span class="dash-photo-badge <?= $foto['Akses']==='publik'?'badge-pub':'badge-priv' ?>">
              <?= $foto['Akses'] ?>
            </span>
            <div class="dash-photo-actions">
              <a href="<?= BASE_URL ?>/edit_foto.php?id=<?= $foto['FotoID'] ?>" class="act-btn act-e" style="text-decoration:none">
                <svg width="13" height="13" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-width="2" d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z"/>
              </svg>
            </a>
            <a href="<?= BASE_URL ?>/hapus_foto.php?id=<?= $foto['FotoID'] ?>"
              onclick="return confirm('Hapus foto ini?')" class="act-btn act-d" style="text-decoration:none">
              <svg width="13" height="13" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/>
              </svg>
            </a>
            </div>
            <div class="dash-photo-info">
              <div class="dash-photo-title"><?= e($foto['JudulFoto']) ?></div>
              <div class="dash-photo-meta">♥ <?= $foto['jmlLike'] ?></div>
            </div>
          </div>
        <?php endforeach; ?>
      <?php else: ?>
        <div class="empty-state" style="grid-column:1/-1">
          <p style="color:var(--wh3);font-family:sans-serif;font-size:13px">
            Belum ada foto. <a href="<?= BASE_URL ?>/upload.php">Unggah sekarang →</a>
          </p>
        </div>
      <?php endif; ?>
    </div>
  </div>

  <!-- TAB ALBUM -->
  <div class="tab-content <?= $tab==='albums'?'act':'' ?>" id="tab-albums">
    <div class="dash-filter-bar">
      <a href="?tab=albums&akses=semua" class="dash-filter-btn <?= $akses==='semua'?'act':'' ?>">Semua</a>
      <a href="?tab=albums&akses=publik" class="dash-filter-btn <?= $akses==='publik'?'act':'' ?>">Publik</a>
      <a href="?tab=albums&akses=private" class="dash-filter-btn <?= $akses==='private'?'act':'' ?>">Private</a>
    </div>

    <details class="album-create-detail">
      <summary class="dash-upload-btn" style="cursor:pointer;list-style:none">
        <svg width="14" height="14" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-width="2" d="M12 4v16m8-8H4"/>
        </svg>
        Buat Album Baru
      </summary>
      <form method="POST" class="album-create-form">
        <input type="hidden" name="csrf_token" value="<?= csrf() ?>">
        <input type="hidden" name="action" value="buat_album">
        <div class="fg">
          <label class="lbl">Nama Album *</label>
          <input class="finput" type="text" name="NamaAlbum" required placeholder="Nama album..." autocomplete="off">
        </div>
        <div class="fg">
          <label class="lbl">Deskripsi</label>
          <textarea class="finput" name="Deskripsi" rows="2" placeholder="Deskripsi singkat..."></textarea>
        </div>
        <div class="fg">
          <label class="lbl">Akses *</label>
          <select class="finput" name="Akses">
            <option value="publik">Publik</option>
            <option value="private">Private</option>
          </select>
        </div>
        <button type="submit" class="auth-btn" style="margin-top:4px">Buat Album</button>
      </form>
    </details>

    <?php if ($albums): ?>
      <?php foreach ($albums as $alb): ?>
        <div class="alb-list-item">
          <div class="alb-thumb">
            <?php if ($alb['coverFile']): ?>
              <img src="<?= BASE_URL ?>/uploads/<?= e($alb['coverFile']) ?>" style="width:100%;height:100%;object-fit:cover;border-radius:6px">
            <?php else: ?>
              <svg width="14" height="14" fill="none" stroke="rgba(255,255,255,0.2)" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-width="1.5" d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z"/>
              </svg>
            <?php endif; ?>
          </div>
          <div class="alb-info">
            <div class="alb-nm"><?= e($alb['NamaAlbum']) ?></div>
            <div class="alb-mt">
              <?= $alb['jmlFoto'] ?> foto ·
              <span class="<?= $alb['Akses']==='publik'?'badge-pub':'badge-priv' ?>"
                    style="padding:1px 6px;border-radius:10px;font-size:9px"><?= $alb['Akses'] ?></span>
            </div>
          </div>
          <div class="alb-acts">
            <a href="<?= BASE_URL ?>/album.php?id=<?= $alb['AlbumID'] ?>" class="btn-alb-e">Lihat</a>
            <a href="?hapus_album=<?= $alb['AlbumID'] ?>" class="btn-alb-d"
               onclick="return confirm('Hapus album ini?')" style="text-decoration:none;display:inline-block;border:none;cursor:pointer">Hapus</a>
          </div>
        </div>
      <?php endforeach; ?>
    <?php else: ?>
      <div class="empty-state">
        <p style="color:var(--wh3);font-family:sans-serif;font-size:13px">Belum ada album.</p>
      </div>
    <?php endif; ?>
  </div>
</div>

<?php
$extraJs = <<<JS
document.querySelectorAll('#dash-tabs .tab-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('#dash-tabs .tab-btn').forEach(b => b.classList.remove('act'));
    document.querySelectorAll('.tab-content').forEach(t => t.classList.remove('act'));
    btn.classList.add('act');
    document.getElementById('tab-' + btn.dataset.tab).classList.add('act');
  });
});
JS;
require_once 'includes/footer.php';
?>
