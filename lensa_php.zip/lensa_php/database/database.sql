-- ============================================
-- Lensa Bercerita - Database Setup
-- Jalankan file ini di phpMyAdmin
-- ============================================

CREATE DATABASE IF NOT EXISTS gallery CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE gallery;

CREATE TABLE IF NOT EXISTS `user` (
  `UserID`       INT(11)      NOT NULL AUTO_INCREMENT,
  `Username`     VARCHAR(255) NOT NULL,
  `Password`     VARCHAR(255) NOT NULL,
  `Email`        VARCHAR(255) NOT NULL,
  `NamaLengkap`  VARCHAR(255) DEFAULT NULL,
  `Alamat`       TEXT         DEFAULT NULL,
  PRIMARY KEY (`UserID`),
  UNIQUE KEY `Username` (`Username`),
  UNIQUE KEY `Email` (`Email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `album` (
  `AlbumID`       INT(11)      NOT NULL AUTO_INCREMENT,
  `NamaAlbum`     VARCHAR(255) NOT NULL,
  `Deskripsi`     TEXT         DEFAULT NULL,
  `TanggalDibuat` DATE         NOT NULL,
  `UserID`        INT(11)      NOT NULL,
  `Akses`         ENUM('publik','private') DEFAULT 'publik',
  PRIMARY KEY (`AlbumID`),
  FOREIGN KEY (`UserID`) REFERENCES `user`(`UserID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `foto` (
  `FotoID`        INT(11)      NOT NULL AUTO_INCREMENT,
  `JudulFoto`     VARCHAR(255) NOT NULL,
  `DeskripsiFoto` TEXT         DEFAULT NULL,
  `TanggalUnggah` DATE         NOT NULL,
  `LokasiFile`    VARCHAR(255) NOT NULL,
  `AlbumID`       INT(11)      DEFAULT NULL,
  `UserID`        INT(11)      NOT NULL,
  `Akses`         ENUM('publik','private') DEFAULT 'publik',
  PRIMARY KEY (`FotoID`),
  FOREIGN KEY (`AlbumID`) REFERENCES `album`(`AlbumID`) ON DELETE SET NULL,
  FOREIGN KEY (`UserID`) REFERENCES `user`(`UserID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `komentarfoto` (
  `KomentarID`      INT(11) NOT NULL AUTO_INCREMENT,
  `FotoID`          INT(11) NOT NULL,
  `UserID`          INT(11) NOT NULL,
  `IsiKomentar`     TEXT    NOT NULL,
  `TanggalKomentar` DATE    NOT NULL,
  PRIMARY KEY (`KomentarID`),
  FOREIGN KEY (`FotoID`) REFERENCES `foto`(`FotoID`) ON DELETE CASCADE,
  FOREIGN KEY (`UserID`) REFERENCES `user`(`UserID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `likefoto` (
  `LikeID`      INT(11) NOT NULL AUTO_INCREMENT,
  `FotoID`      INT(11) NOT NULL,
  `UserID`      INT(11) NOT NULL,
  `TanggalLike` DATE    NOT NULL,
  PRIMARY KEY (`LikeID`),
  UNIQUE KEY `unique_like` (`FotoID`,`UserID`),
  FOREIGN KEY (`FotoID`) REFERENCES `foto`(`FotoID`) ON DELETE CASCADE,
  FOREIGN KEY (`UserID`) REFERENCES `user`(`UserID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
