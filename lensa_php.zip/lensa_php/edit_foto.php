<?php
require_once 'includes/config.php';
require_once 'includes/db.php';
require_once 'includes/auth.php';

requireLogin();
$user  = currentUser();
$uid   = $user['UserID'];
$id    = (int)($_GET['id'] ?? 0);
$error = '';

$foto = queryOne("SELECT * FROM foto WHERE FotoID=? AND UserID=?", [$id,$uid], 'ii');
if (!$foto) { flash('error','Foto tidak ditemukan'); redirect('dashboard.php'); }

if (isPost()) {
    verifyCsrf();
    $judul  = trim($_POST['JudulFoto'] ?? '');
    $desk   = trim($_POST['DeskripsiFoto'] ?? '');
    $albumId = (int)($_POST['AlbumID'] ?? 0) ?: null;
    $akses  = $_POST['Akses'] ?? 'publik';
    $lokasiFile = $foto['LokasiFile'];

    if (empty($judul)) {
        $error = 'Judul foto wajib diisi.';
    } else {
        if (!empty($_FILES['foto']['name'])) {
            $upload = uploadFoto($_FILES['foto']);
            if (isset($upload['error'])) {
                $error = $upload['error'];
            } else {
                deleteFile($foto['LokasiFile']);
                $lokasiFile = $upload['filename'];
            }
        }
        if (empty($error)) {
            execute(
                "UPDATE foto SET JudulFoto=?,DeskripsiFoto=?,LokasiFile=?,AlbumID=?,Akses=? WHERE FotoID=?",
                [$judul,$desk,$lokasiFile,$albumId,$akses,$id], 'sssisi'
            );
            flash('success','Foto berhasil diperbarui!');
            redirect('dashboard.php');
        }
    }
}

$albums = queryAll("SELECT AlbumID,NamaAlbum FROM album WHERE UserID=? ORDER BY NamaAlbum", [$uid], 'i');
$pageTitle = 'Edit Foto — Lensa Bercerita';
require_once 'includes/header.php';
?>

<div class="form-wrap">
  <div class="form-header">
    <h2 class="form-title">Edit Foto</h2>
    <a href="<?= BASE_URL ?>/dashboard.php" class="form-back">← Kembali</a>
  </div>

  <?php if ($error): ?>
    <div class="alert-error"><?= e($error) ?></div>
  <?php endif; ?>

  <form method="POST" enctype="multipart/form-data">
    <input type="hidden" name="csrf_token" value="<?= csrf() ?>">

    <div class="edit-current-img">
      <img src="<?= BASE_URL ?>/uploads/<?= e($foto['LokasiFile']) ?>" alt="<?= e($foto['JudulFoto']) ?>"
           style="max-height:220px;border-radius:8px;object-fit:contain;display:block;margin-bottom:10px">
      <p style="font-family:sans-serif;font-size:11px;color:var(--wh3)">Foto saat ini · Kosongkan untuk mempertahankan</p>
    </div>

    <div class="fg">
      <label class="lbl">Ganti Foto (opsional)</label>
      <div class="drop-zone" id="drop-zone" onclick="document.getElementById('file-input').click()" style="min-height:80px">
        <div class="drop-zone-inner" id="drop-preview">
          <p style="font-family:sans-serif;font-size:12px;color:var(--wh3)">Klik untuk pilih foto baru</p>
        </div>
        <input type="file" id="file-input" name="foto" accept="image/*" style="display:none">
      </div>
    </div>

    <div class="fg">
      <label class="lbl">Judul Foto *</label>
      <input class="finput" type="text" name="JudulFoto" value="<?= e($foto['JudulFoto']) ?>" required>
    </div>
    <div class="fg">
      <label class="lbl">Deskripsi</label>
      <textarea class="finput" name="DeskripsiFoto" rows="3"><?= e($foto['DeskripsiFoto']) ?></textarea>
    </div>
    <div class="two-col">
      <div class="fg">
        <label class="lbl">Album</label>
        <select class="finput" name="AlbumID" style="cursor:pointer">
          <option value="">-- Tanpa Album --</option>
          <?php foreach ($albums as $alb): ?>
            <option value="<?= $alb['AlbumID'] ?>" <?= $foto['AlbumID']==$alb['AlbumID']?'selected':'' ?>>
              <?= e($alb['NamaAlbum']) ?>
            </option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="fg">
        <label class="lbl">Akses *</label>
        <select class="finput" name="Akses" style="cursor:pointer">
          <option value="publik" <?= $foto['Akses']==='publik'?'selected':'' ?>>Publik</option>
          <option value="private" <?= $foto['Akses']==='private'?'selected':'' ?>>Private</option>
        </select>
      </div>
    </div>
    <div style="display:flex;gap:10px;margin-top:8px">
      <button type="submit" class="auth-btn">Simpan Perubahan</button>
      <a href="<?= BASE_URL ?>/dashboard.php" class="btn-sm btn-o" style="padding:9px 20px;text-decoration:none;border-radius:6px;font-size:13px;font-family:sans-serif">Batal</a>
    </div>
  </form>
</div>

<?php
$extraJs = <<<JS
const fi=document.getElementById('file-input');
const preview=document.getElementById('drop-preview');
fi.addEventListener('change',()=>{
  const file=fi.files[0];if(!file)return;
  const reader=new FileReader();
  reader.onload=e=>{
    preview.innerHTML=`<img src="\${e.target.result}" style="max-height:140px;border-radius:6px;object-fit:contain">
      <p style="font-family:sans-serif;font-size:11px;color:var(--wh3);margin-top:6px">\${file.name}</p>`;
  };
  reader.readAsDataURL(file);
});
JS;
require_once 'includes/footer.php';
?>
