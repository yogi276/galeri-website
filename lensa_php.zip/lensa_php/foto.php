<?php
require_once 'includes/config.php';
require_once 'includes/db.php';
require_once 'includes/auth.php';

requireLogin();

$id   = (int)($_GET['id'] ?? 0);
$user = currentUser();

// Handle AJAX like
if (isPost() && isset($_POST['action']) && $_POST['action'] === 'like') {
    $existing = queryOne("SELECT LikeID FROM likefoto WHERE FotoID=? AND UserID=?", [$id, $user['UserID']], 'ii');
    if ($existing) {
        execute("DELETE FROM likefoto WHERE FotoID=? AND UserID=?", [$id, $user['UserID']], 'ii');
        $liked = false;
    } else {
        insert("INSERT INTO likefoto (FotoID,UserID,TanggalLike) VALUES (?,?,CURDATE())", [$id,$user['UserID']], 'ii');
        $liked = true;
    }
    $count = queryOne("SELECT COUNT(*) as c FROM likefoto WHERE FotoID=?", [$id], 'i')['c'];
    jsonResponse(['liked'=>$liked,'count'=>$count]);
}

// Handle AJAX komentar POST
if (isPost() && isset($_POST['action']) && $_POST['action'] === 'komentar') {
    $isi = trim($_POST['IsiKomentar'] ?? '');
    if (empty($isi)) jsonResponse(['success'=>false,'error'=>'Komentar kosong']);
    $kid = insert(
        "INSERT INTO komentarfoto (FotoID,UserID,IsiKomentar,TanggalKomentar) VALUES (?,?,?,CURDATE())",
        [$id,$user['UserID'],$isi], 'iis'
    );
    jsonResponse([
        'success'         => true,
        'KomentarID'      => $kid,
        'IsiKomentar'     => $isi,
        'Username'        => $user['Username'],
        'NamaLengkap'     => $user['NamaLengkap'],
        'TanggalKomentar' => date('d M Y'),
    ]);
}

// Handle AJAX komentar DELETE
if (isPost() && isset($_POST['action']) && $_POST['action'] === 'hapus_komentar') {
    $kid = (int)($_POST['KomentarID'] ?? 0);
    $kom = queryOne("SELECT * FROM komentarfoto WHERE KomentarID=?", [$kid], 'i');
    if ($kom && $kom['UserID'] == $user['UserID']) {
        execute("DELETE FROM komentarfoto WHERE KomentarID=?", [$kid], 'i');
        jsonResponse(['success'=>true]);
    }
    jsonResponse(['success'=>false]);
}

// Handle AJAX komentar EDIT
if (isPost() && isset($_POST['action']) && $_POST['action'] === 'edit_komentar') {
    $kid = (int)($_POST['KomentarID'] ?? 0);
    $isi = trim($_POST['IsiKomentar'] ?? '');
    $kom = queryOne("SELECT * FROM komentarfoto WHERE KomentarID=?", [$kid], 'i');
    if ($kom && $kom['UserID'] == $user['UserID'] && !empty($isi)) {
        execute("UPDATE komentarfoto SET IsiKomentar=? WHERE KomentarID=?", [$isi,$kid], 'si');
        jsonResponse(['success'=>true,'IsiKomentar'=>$isi]);
    }
    jsonResponse(['success'=>false]);
}

// Load foto
$foto = queryOne("
    SELECT f.*, u.Username, u.NamaLengkap,
           a.NamaAlbum, a.AlbumID as AlbumIDx, a.Deskripsi as DeskripsiAlbum
    FROM foto f
    JOIN user u ON f.UserID=u.UserID
    LEFT JOIN album a ON f.AlbumID=a.AlbumID
    WHERE f.FotoID=?
", [$id], 'i');

if (!$foto) { flash('error','Foto tidak ditemukan'); redirect('home.php'); }
if ($foto['Akses'] === 'private' && $foto['UserID'] != $user['UserID']) {
    flash('error','Foto ini bersifat private'); redirect('home.php');
}

// Like status
$sudahLike = queryOne("SELECT LikeID FROM likefoto WHERE FotoID=? AND UserID=?", [$id,$user['UserID']], 'ii');
$jmlLike   = queryOne("SELECT COUNT(*) as c FROM likefoto WHERE FotoID=?", [$id], 'i')['c'];

// Komentar
$komentar = queryAll("
    SELECT k.*, u.Username, u.NamaLengkap
    FROM komentarfoto k JOIN user u ON k.UserID=u.UserID
    WHERE k.FotoID=? ORDER BY k.KomentarID ASC
", [$id], 'i');

// Prev / Next dalam album
$prevFoto = $nextFoto = null;
$albumFotos = [];
if ($foto['AlbumID']) {
    $prevFoto = queryOne("
    SELECT FotoID, LokasiFile, JudulFoto FROM foto
    WHERE AlbumID=? AND FotoID<? AND Akses='publik'
    ORDER BY FotoID DESC LIMIT 1
", [$foto['AlbumID'], $id], 'ii');

$nextFoto = queryOne("
    SELECT FotoID, LokasiFile, JudulFoto FROM foto
    WHERE AlbumID=? AND FotoID>? AND Akses='publik'
    ORDER BY FotoID ASC LIMIT 1
", [$foto['AlbumID'], $id], 'ii');
    $albumFotos = queryAll("
    SELECT FotoID, LokasiFile, JudulFoto FROM foto
    WHERE AlbumID=? AND Akses='publik'
    ORDER BY FotoID ASC
", [$foto['AlbumID']], 'i');
}

$pageTitle = e($foto['JudulFoto']) . ' — Lensa Bercerita';
require_once 'includes/header.php';
?>

<div class="foto-page">

  <!-- KIRI -->
  <div class="foto-left">
    <a href="<?= BASE_URL ?>/home.php" class="foto-back">
      <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path stroke-linecap="round" stroke-width="2" d="M15 19l-7-7 7-7"/>
      </svg>
      Kembali
    </a>

    <div class="foto-img-container">
      <?php if ($prevFoto): ?>
        <a href="<?= BASE_URL ?>/foto.php?id=<?= $prevFoto['FotoID'] ?>" class="foto-arrow foto-arrow-left">
          <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-width="2.5" d="M15 19l-7-7 7-7"/>
          </svg>
        </a>
      <?php endif; ?>

      <div class="foto-img-wrap">
        <img src="<?= BASE_URL ?>/uploads/<?= e($foto['LokasiFile']) ?>" alt="<?= e($foto['JudulFoto']) ?>">
      </div>

      <?php if ($nextFoto): ?>
        <a href="<?= BASE_URL ?>/foto.php?id=<?= $nextFoto['FotoID'] ?>" class="foto-arrow foto-arrow-right">
          <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-width="2.5" d="M9 5l7 7-7 7"/>
          </svg>
        </a>
      <?php endif; ?>
    </div>

    <!-- Strip thumbnail -->
    <?php if ($albumFotos && count($albumFotos) > 1): ?>
    <div class="foto-strip-wrap">
      <?php if (count($albumFotos) > 5): ?>
        <button class="strip-arrow" onclick="scrollStrip(-1)">
          <svg width="14" height="14" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-width="2.5" d="M15 19l-7-7 7-7"/>
          </svg>
        </button>
      <?php endif; ?>
      <div class="foto-strip" id="foto-strip">
        <?php foreach ($albumFotos as $af): ?>
          <a href="<?= BASE_URL ?>/foto.php?id=<?= $af['FotoID'] ?>"
             class="foto-strip-item <?= $af['FotoID'] == $id ? 'act' : '' ?>">
            <img src="<?= BASE_URL ?>/uploads/<?= e($af['LokasiFile']) ?>" alt="<?= e($af['JudulFoto']) ?>">
          </a>
        <?php endforeach; ?>
      </div>
      <?php if (count($albumFotos) > 5): ?>
        <button class="strip-arrow" onclick="scrollStrip(1)">
          <svg width="14" height="14" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-width="2.5" d="M9 5l7 7-7 7"/>
          </svg>
        </button>
      <?php endif; ?>
    </div>
    <?php endif; ?>
  </div>

  <!-- KANAN -->
<div class="foto-right">

  <!-- Album info (jika ada album) -->
  <?php if ($foto['NamaAlbum']): ?>
  <div class="sidebar-section sidebar-album">
    <div class="sidebar-label">Dari Album</div>
    <div class="sidebar-album-title"><?= e($foto['NamaAlbum']) ?></div>
<?php if (!empty($foto['DeskripsiAlbum'])): ?>
  <div class="sidebar-scroll-text" style="margin-top:6px"><?= e($foto['DeskripsiAlbum']) ?></div>
<?php endif; ?>
  </div>
  <?php endif; ?>

  <!-- Foto info -->
  <div class="sidebar-section sidebar-foto-info">
    <?php if ($foto['NamaAlbum']): ?>
      <div class="sidebar-label"><?= e(strtoupper('Foto')) ?></div>
    <?php endif; ?>
    <div class="sidebar-foto-title"><?= e($foto['JudulFoto']) ?></div>
    <?php if ($foto['DeskripsiFoto'] && $foto['DeskripsiFoto'] !== '.'): ?>
      <div class="sidebar-scroll-text"><?= e($foto['DeskripsiFoto']) ?></div>
    <?php endif; ?>
  </div>

  <!-- Profile pengunggah -->
  <div class="sidebar-section sidebar-author">
    <div class="avatar" style="width:34px;height:34px;font-size:13px;border:none;background:var(--bk3);flex-shrink:0">
      <?= strtoupper(substr($foto['Username'],0,1)) ?>
    </div>
    <div>
      <div style="font-size:13px;font-weight:600"><?= e($foto['Username']) ?></div>
      <div style="font-size:11px;color:var(--wh3);font-family:sans-serif"><?= e($foto['NamaLengkap']) ?></div>
    </div>
  </div>

  <!-- Like + tanggal + aksi -->
  <div class="sidebar-section sidebar-actions">
    <button class="like-btn <?= $sudahLike ? 'liked' : '' ?>" id="like-btn" onclick="toggleLike(<?= $id ?>)">
      <svg width="16" height="16" fill="<?= $sudahLike ? 'currentColor' : 'none' ?>" stroke="currentColor"
           id="like-icon" viewBox="0 0 24 24">
        <path stroke-linecap="round" stroke-width="2" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"/>
      </svg>
      <span id="like-count"><?= $jmlLike ?></span>
    </button>
    <span style="font-size:11px;color:var(--wh3);font-family:sans-serif">
      <?= date('d M Y', strtotime($foto['TanggalUnggah'])) ?>
    </span>
    <?php if ($foto['UserID'] == $user['UserID']): ?>
      <a href="<?= BASE_URL ?>/edit_foto.php?id=<?= $id ?>" style="font-size:11px;color:var(--wh3);font-family:sans-serif;text-decoration:none">Edit</a>
      <a href="<?= BASE_URL ?>/hapus_foto.php?id=<?= $id ?>"
         onclick="return confirm('Hapus foto ini?')"
         style="font-size:11px;color:var(--red);font-family:sans-serif;text-decoration:none">Hapus</a>
    <?php endif; ?>
  </div>

  <!-- Input komentar -->
  <div class="sidebar-section sidebar-comment-input">
    <input type="text" id="comment-input" class="comment-input" placeholder="Tulis komentar..." autocomplete="off">
    <button class="comment-send" onclick="kirimKomentar(<?= $id ?>)">
      <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path stroke-linecap="round" stroke-width="2" d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8"/>
      </svg>
    </button>
  </div>

  <!-- Daftar komentar -->
  <div class="sidebar-section sidebar-comments">
    <div class="comments-title" id="komentar-count"><?= count($komentar) ?> Komentar</div>
    <div class="comments-scroll" id="comments-list">
      <?php foreach ($komentar as $kom): ?>
        <div class="comment-item" id="citem-<?= $kom['KomentarID'] ?>">
          <div class="avatar" style="width:26px;height:26px;font-size:10px;border:none;background:var(--bk3);flex-shrink:0">
            <?= strtoupper(substr($kom['Username'],0,1)) ?>
          </div>
          <div class="comment-body">
            <div class="comment-uname"><?= e($kom['Username']) ?></div>
            <div class="comment-text" id="ctxt-<?= $kom['KomentarID'] ?>"><?= e($kom['IsiKomentar']) ?></div>
            <div class="comment-meta">
              <span><?= timeAgo($kom['TanggalKomentar']) ?></span>
              <?php if ($kom['UserID'] == $user['UserID']): ?>
                <span style="color:var(--wh3);cursor:pointer" onclick="editKomentar(<?= $kom['KomentarID'] ?>)">Edit</span>
                <span style="color:var(--red);cursor:pointer" onclick="hapusKomentar(<?= $kom['KomentarID'] ?>)">Hapus</span>
              <?php endif; ?>
            </div>
            <div id="cedit-<?= $kom['KomentarID'] ?>" style="display:none;margin-top:6px">
              <textarea id="cinput-<?= $kom['KomentarID'] ?>" class="comment-edit-input" rows="2"><?= e($kom['IsiKomentar']) ?></textarea>
              <div style="display:flex;gap:5px;margin-top:4px">
                <button class="btn-save-kom" onclick="simpanKomentar(<?= $kom['KomentarID'] ?>)">Simpan</button>
                <button class="btn-cancel-kom" onclick="batalEdit(<?= $kom['KomentarID'] ?>)">Batal</button>
              </div>
            </div>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  </div>

</div>

<?php require_once 'includes/footer.php'; ?>
<script>
const BASE = '<?= BASE_URL ?>';
const FOTO_ID = <?= $id ?>;

let likeLoading = false;
async function toggleLike(fotoId) {
  if (likeLoading) return;
  likeLoading = true;
  const btn = document.getElementById('like-btn');
  const icon = document.getElementById('like-icon');
  const countEl = document.getElementById('like-count');
  const isLiked = btn.classList.contains('liked');
  const cur = parseInt(countEl.textContent);
  btn.classList.toggle('liked', !isLiked);
  icon.setAttribute('fill', !isLiked ? 'currentColor' : 'none');
  countEl.textContent = !isLiked ? cur + 1 : cur - 1;
  try {
    const fd = new FormData();
    fd.append('action', 'like');
    fd.append('foto_id', fotoId);
    const res = await fetch(BASE + '/ajax.php', {method:'POST', body:fd});
    const data = await res.json();
    btn.classList.toggle('liked', data.liked);
    icon.setAttribute('fill', data.liked ? 'currentColor' : 'none');
    countEl.textContent = data.count;
  } catch(e) {
    btn.classList.toggle('liked', isLiked);
    icon.setAttribute('fill', isLiked ? 'currentColor' : 'none');
    countEl.textContent = cur;
  }
  likeLoading = false;
}

async function kirimKomentar(fotoId) {
  const input = document.getElementById('comment-input');
  const txt = input.value.trim();
  if (!txt) return;
  input.disabled = true;
  try {
    const fd = new FormData();
    fd.append('action', 'komentar');
    fd.append('foto_id', fotoId);
    fd.append('IsiKomentar', txt);
    const res = await fetch(BASE + '/ajax.php', {method:'POST', body:fd});
    const data = await res.json();
    if (data.success) {
      const list = document.getElementById('comments-list');
      const title = document.getElementById('komentar-count');
      const count = list.querySelectorAll('.comment-item').length + 1;
      title.textContent = count + ' Komentar';
      const div = document.createElement('div');
      div.className = 'comment-item';
      div.id = 'citem-' + data.KomentarID;
      div.innerHTML = `
        <div class="avatar" style="width:26px;height:26px;font-size:10px;border:none;background:var(--bk3);flex-shrink:0">
          ${data.Username[0].toUpperCase()}
        </div>
        <div class="comment-body">
          <div class="comment-uname">${data.Username}</div>
          <div class="comment-text" id="ctxt-${data.KomentarID}">${data.IsiKomentar}</div>
          <div class="comment-meta">
            <span>${data.TanggalKomentar}</span>
            <span style="color:var(--wh3);cursor:pointer" onclick="editKomentar(${data.KomentarID})">Edit</span>
            <span style="color:var(--red);cursor:pointer" onclick="hapusKomentar(${data.KomentarID})">Hapus</span>
          </div>
          <div id="cedit-${data.KomentarID}" style="display:none;margin-top:6px">
            <textarea id="cinput-${data.KomentarID}" class="comment-edit-input" rows="2">${data.IsiKomentar}</textarea>
            <div style="display:flex;gap:5px;margin-top:4px">
              <button class="btn-save-kom" onclick="simpanKomentar(${data.KomentarID})">Simpan</button>
              <button class="btn-cancel-kom" onclick="batalEdit(${data.KomentarID})">Batal</button>
            </div>
          </div>
        </div>`;
      list.appendChild(div);
      list.scrollTop = list.scrollHeight;
      input.value = '';
    }
  } catch(e) {
    alert('Gagal mengirim komentar.');
  }
  input.disabled = false;
  input.focus();
}

document.getElementById('comment-input').addEventListener('keydown', function(e) {
  if (e.key === 'Enter') kirimKomentar(FOTO_ID);
});

function editKomentar(id) {
  document.getElementById('ctxt-' + id).style.display = 'none';
  document.getElementById('cedit-' + id).style.display = 'block';
}
function batalEdit(id) {
  document.getElementById('ctxt-' + id).style.display = 'block';
  document.getElementById('cedit-' + id).style.display = 'none';
}
async function simpanKomentar(id) {
  const val = document.getElementById('cinput-' + id).value;
  const fd = new FormData();
  fd.append('action', 'edit_komentar');
  fd.append('foto_id', FOTO_ID);
  fd.append('KomentarID', id);
  fd.append('IsiKomentar', val);
  const res = await fetch(BASE + '/ajax.php', {method:'POST', body:fd});
  const data = await res.json();
  if (data.success) {
    document.getElementById('ctxt-' + id).textContent = data.IsiKomentar;
    batalEdit(id);
  }
}
async function hapusKomentar(id) {
  if (!confirm('Hapus komentar ini?')) return;
  const fd = new FormData();
  fd.append('action', 'hapus_komentar');
  fd.append('foto_id', FOTO_ID);
  fd.append('KomentarID', id);
  const res = await fetch(BASE + '/ajax.php', {method:'POST', body:fd});
  const data = await res.json();
  if (data.success) {
    document.getElementById('citem-' + id)?.remove();
    const list = document.getElementById('comments-list');
    const title = document.getElementById('komentar-count');
    title.textContent = list.querySelectorAll('.comment-item').length + ' Komentar';
  }
}
</script>
