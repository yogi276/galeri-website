<?php
require_once 'includes/config.php';
require_once 'includes/db.php';
require_once 'includes/auth.php';

requireLogin();
$user = currentUser();
$uid  = $user['UserID'];
$id   = (int)($_GET['id'] ?? 0);

$foto = queryOne("SELECT * FROM foto WHERE FotoID=? AND UserID=?", [$id,$uid], 'ii');
if ($foto) {
    deleteFile($foto['LokasiFile']);
    execute("DELETE FROM foto WHERE FotoID=?", [$id], 'i');
    flash('success', 'Foto berhasil dihapus!');
} else {
    flash('error', 'Foto tidak ditemukan.');
}

redirect('dashboard.php');
