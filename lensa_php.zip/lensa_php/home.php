<?php
require_once 'includes/config.php';
require_once 'includes/db.php';
require_once 'includes/auth.php';

requireLogin();

$pageTitle = 'Discover — Lensa Bercerita';
$fotos = queryAll("
    SELECT f.*, u.Username, u.NamaLengkap,
           (SELECT COUNT(*) FROM likefoto WHERE FotoID=f.FotoID) as jmlLike
    FROM foto f
    JOIN user u ON f.UserID=u.UserID
    WHERE f.Akses='publik' AND f.AlbumID IS NULL
    ORDER BY f.FotoID DESC
");
$albums = queryAll("
    SELECT a.*, u.Username,
           (SELECT LokasiFile FROM foto WHERE AlbumID=a.AlbumID ORDER BY FotoID ASC LIMIT 1) as coverFile,
           (SELECT FotoID FROM foto WHERE AlbumID=a.AlbumID ORDER BY FotoID ASC LIMIT 1) as firstFotoID,
           (SELECT COUNT(*) FROM foto WHERE AlbumID=a.AlbumID) as jmlFoto
    FROM album a
    JOIN user u ON a.UserID=u.UserID
    WHERE a.Akses='publik'
    HAVING jmlFoto > 0
    ORDER BY a.AlbumID DESC
    LIMIT 8
");
require_once 'includes/header.php';
?>
<div class="disc-wrap">
  <div class="disc-header">
    <div class="sec-title">Discover</div>
    <p class="disc-sub">Temukan karya foto terbaik dari komunitas</p>
  </div>
  <?php
  $semua = [];
  foreach ($fotos as $f) {
      $semua[] = [
          'type'    => 'foto',
          'id'      => $f['FotoID'],
          'judul'   => $f['JudulFoto'],
          'file'    => $f['LokasiFile'],
          'user'    => $f['Username'],
          'like'    => $f['jmlLike'],
          'url'     => BASE_URL . '/foto.php?id=' . $f['FotoID'],
      ];
  }
  foreach ($albums as $a) {
      $semua[] = [
          'type'  => 'album',
          'id'    => $a['AlbumID'],
          'judul' => $a['NamaAlbum'],
          'file'  => $a['coverFile'],
          'user'  => $a['Username'],
          'like'  => $a['jmlFoto'] . ' foto',
          'url'   => BASE_URL . '/foto.php?id=' . $a['firstFotoID'],
      ];
  }
  ?>
  <?php if ($semua): ?>
    <div class="disc-grid-masonry">
      <?php foreach ($semua as $item): ?>
        <a href="<?= $item['url'] ?>" class="disc-item" style="text-decoration:none">
          <div class="disc-img-wrap">
            <?php if ($item['file']): ?>
              <img src="<?= BASE_URL ?>/uploads/<?= e($item['file']) ?>"
                   alt="<?= e($item['judul']) ?>"
                   style="width:100%;height:100%;object-fit:cover">
            <?php else: ?>
              <div style="width:100%;height:100%;display:flex;align-items:center;justify-content:center">
                <svg width="32" height="32" fill="none" stroke="rgba(255,255,255,0.15)" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-width="1.5" d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z"/>
                </svg>
              </div>
            <?php endif; ?>
            <div class="disc-overlay">
              <div class="disc-title"><?= e($item['judul']) ?></div>
              <div class="disc-meta">
                <span><?= e($item['user']) ?></span>
                <span><?= $item['type'] === 'foto' ? '♥ ' . $item['like'] : $item['like'] ?></span>
              </div>
            </div>
          </div>
        </a>
      <?php endforeach; ?>
    </div>
  <?php else: ?>
    <div class="empty-state">
      <p style="color:var(--wh3);font-family:sans-serif">Belum ada konten.</p>
    </div>
  <?php endif; ?>
</div>
<?php require_once 'includes/footer.php'; ?>
