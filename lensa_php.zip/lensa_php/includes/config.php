<?php
// includes/config.php

define('BASE_URL', 'http://localhost/lensa_php');
define('UPLOAD_DIR', __DIR__ . '/../uploads/');
define('UPLOAD_URL', BASE_URL . '/uploads/');
