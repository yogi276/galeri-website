<?php
// includes/db.php

define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'gallery');

function getDB() {
    static $conn = null;
    if ($conn === null) {
        $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
        $conn->set_charset('utf8mb4');
        if ($conn->connect_error) {
            die('Koneksi database gagal: ' . $conn->connect_error);
        }
    }
    return $conn;
}

function query($sql, $params = [], $types = '') {
    $db = getDB();
    if (empty($params)) {
        $result = $db->query($sql);
        if ($result === false) die('Query error: ' . $db->error);
        return $result;
    }
    $stmt = $db->prepare($sql);
    if (!$stmt) die('Prepare error: ' . $db->error);
    if (!empty($params)) {
        $stmt->bind_param($types, ...$params);
    }
    $stmt->execute();
    $result = $stmt->get_result();
    $stmt->close();
    return $result;
}

function queryOne($sql, $params = [], $types = '') {
    $result = query($sql, $params, $types);
    if ($result && $result->num_rows > 0) {
        return $result->fetch_assoc();
    }
    return null;
}

function queryAll($sql, $params = [], $types = '') {
    $result = query($sql, $params, $types);
    $rows = [];
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $rows[] = $row;
        }
    }
    return $rows;
}

function insert($sql, $params = [], $types = '') {
    $db = getDB();
    $stmt = $db->prepare($sql);
    if (!$stmt) die('Prepare error: ' . $db->error);
    if (!empty($params)) {
        $stmt->bind_param($types, ...$params);
    }
    $stmt->execute();
    $id = $stmt->insert_id;
    $stmt->close();
    return $id;
}

function execute($sql, $params = [], $types = '') {
    $db = getDB();
    $stmt = $db->prepare($sql);
    if (!$stmt) die('Prepare error: ' . $db->error);
    if (!empty($params)) {
        $stmt->bind_param($types, ...$params);
    }
    $result = $stmt->execute();
    $stmt->close();
    return $result;
}
