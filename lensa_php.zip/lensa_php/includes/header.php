<?php
// includes/header.php
$user = currentUser();
$successMsg = flash('success');
$errorMsg = flash('error');
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= $pageTitle ?? 'Lensa Bercerita' ?></title>
<link rel="icon" type="image/png" href="<?= BASE_URL ?>/assets/images/logo.png">
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/app.css">
</head>
<body>

<nav>
  <div class="nav-left">
    <a href="<?= BASE_URL ?>/<?= isLoggedIn() ? 'home.php' : 'index.php' ?>" class="logo">
      <img src="<?= BASE_URL ?>/assets/images/logo.png" alt="Logo"
           style="width:28px;height:28px;object-fit:contain;filter:invert(1)">
      Lensa Bercerita
    </a>
  </div>
  <div class="nav-right-group">
    <?php if (isLoggedIn()): ?>
      <a href="<?= BASE_URL ?>/upload.php" class="btn-sm btn-w" style="text-decoration:none">+ Unggah</a>

      <div class="nav-avatar">
        <button class="nav-av-btn" onclick="toggleNavDropdown(event)">
          <?= strtoupper(substr($user['Username'], 0, 1)) ?>
        </button>
        <div class="nav-dropdown" id="nav-dropdown">
          <div class="nav-dd-item danger">
            <svg width="14" height="14" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"/>
            </svg>
            <a href="<?= BASE_URL ?>/logout.php" style="color:inherit;text-decoration:none">Keluar</a>
          </div>
        </div>
      </div>

      <div class="ham-wrap">
        <button class="hamburger" onclick="toggleHamMenu(event)">
          <span></span><span></span><span></span>
        </button>
        <div class="ham-menu" id="ham-menu">
          <a href="<?= BASE_URL ?>/home.php" class="ham-item <?= basename($_SERVER['PHP_SELF']) === 'home.php' ? 'act' : '' ?>">
            <svg width="15" height="15" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <circle cx="11" cy="11" r="8" stroke-width="2"/>
              <path stroke-linecap="round" stroke-width="2" d="M21 21l-4.35-4.35"/>
            </svg>
            Discover
          </a>
          <div class="ham-sep"></div>
          <a href="<?= BASE_URL ?>/dashboard.php" class="ham-item <?= basename($_SERVER['PHP_SELF']) === 'dashboard.php' ? 'act' : '' ?>">
            <svg width="15" height="15" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h7"/>
            </svg>
            Dashboard
          </a>
        </div>
      </div>

    <?php else: ?>
      <a href="<?= BASE_URL ?>/login.php" class="btn-sm btn-o" style="text-decoration:none">Masuk</a>
      <a href="<?= BASE_URL ?>/register.php" class="btn-sm btn-w" style="text-decoration:none">Daftar</a>
    <?php endif; ?>
  </div>
</nav>

<div class="app">
<?php if ($successMsg): ?>
  <div class="flash-success"><?= e($successMsg) ?></div>
<?php endif; ?>
<?php if ($errorMsg): ?>
  <div class="alert-error" style="border-radius:0;margin:0"><?= e($errorMsg) ?></div>
<?php endif; ?>
