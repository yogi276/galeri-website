<?php
require_once 'includes/config.php';
require_once 'includes/db.php';
require_once 'includes/auth.php';

if (isLoggedIn()) redirect('home.php');

$pageTitle = 'Lensa Bercerita — Platform Galeri Foto';

$totalFoto      = queryOne("SELECT COUNT(*) as c FROM foto WHERE Akses='publik'")['c'];
$totalFotografer = queryOne("SELECT COUNT(*) as c FROM user")['c'];
$totalAlbum     = queryOne("SELECT COUNT(*) as c FROM album WHERE Akses='publik'")['c'];
$totalLike      = queryOne("SELECT COUNT(*) as c FROM likefoto")['c'];
$preview        = queryAll("SELECT * FROM foto WHERE Akses='publik' ORDER BY FotoID DESC LIMIT 6");

require_once 'includes/header.php';
?>

<!-- HERO -->
<div class="hero">
  <div class="hero-l">
    <div class="hero-eyebrow">Platform Galeri Foto</div>
    <h1 class="hero-title">Abadikan<br>Momen,<br><em>Ceritakan</em><br>Dunia</h1>
    <p class="hero-desc">Unggah, kurasi, dan bagikan karya fotografimu. Temukan inspirasi dari ribuan foto yang menakjubkan.</p>
    <div class="hero-cta">
      <a href="<?= BASE_URL ?>/register.php" class="hbtn-main">Mulai Sekarang</a>
      <a href="<?= BASE_URL ?>/login.php" class="hbtn-sec">Sudah punya akun?</a>
    </div>
  </div>
  <div class="hero-r">
    <?php foreach (array_slice($preview, 0, 3) as $i => $p): ?>
      <div class="hero-r-item" <?= $i === 0 ? 'style="grid-row:span 2"' : '' ?>>
        <img src="<?= BASE_URL ?>/uploads/<?= e($p['LokasiFile']) ?>" alt="<?= e($p['JudulFoto']) ?>"
             style="width:100%;height:100%;object-fit:cover">
      </div>
    <?php endforeach; ?>
    <?php for ($i = count(array_slice($preview,0,3)); $i < 3; $i++): ?>
      <div class="hero-r-item" <?= $i === 0 ? 'style="grid-row:span 2"' : '' ?>>
        <div class="photo-placeholder">
          <svg class="pp-icon" width="32" height="32" fill="none" stroke="#fff" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-width="1.5" d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z"/>
            <circle cx="12" cy="13" r="3" stroke-width="1.5"/>
          </svg>
        </div>
      </div>
    <?php endfor; ?>
  </div>
</div>

<!-- COUNTER BAR -->
<div class="counter-bar">
  <div class="ctr"><div class="ctr-num"><?= $totalFoto > 999 ? round($totalFoto/1000,1).'K+' : $totalFoto.'+' ?></div><div class="ctr-label">Foto</div></div>
  <div class="ctr"><div class="ctr-num"><?= $totalFotografer.'+' ?></div><div class="ctr-label">Fotografer</div></div>
  <div class="ctr"><div class="ctr-num"><?= $totalAlbum.'+' ?></div><div class="ctr-label">Album</div></div>
  <div class="ctr"><div class="ctr-num"><?= $totalLike > 999 ? round($totalLike/1000,1).'K+' : $totalLike.'+' ?></div><div class="ctr-label">Apresiasi</div></div>
</div>

<!-- PREVIEW GALLERY -->
<div style="padding:28px 24px">
  <div class="sec-head">
    <div class="sec-title">Karya Terbaru</div>
    <a href="<?= BASE_URL ?>/login.php" class="sec-link">Lihat Semua →</a>
  </div>
  <div class="landing-grid">
    <?php foreach ($preview as $i => $foto): ?>
      <div class="lgi <?= $i === 0 ? 'lgi-big' : '' ?>">
        <img src="<?= BASE_URL ?>/uploads/<?= e($foto['LokasiFile']) ?>" alt="<?= e($foto['JudulFoto']) ?>"
             style="width:100%;height:100%;object-fit:cover">
        <div class="lock-ov">
          <div class="lock-circle">
            <svg width="14" height="14" fill="none" stroke="white" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-width="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"/>
            </svg>
          </div>
          <div class="lock-txt">Login untuk interaksi</div>
        </div>
      </div>
    <?php endforeach; ?>
    <?php for ($i = count($preview); $i < 6; $i++): ?>
      <div class="lgi <?= $i === 0 ? 'lgi-big' : '' ?>" style="background:#1a1a1a">
        <div class="ph-box">
          <svg width="20" height="20" fill="none" stroke="rgba(255,255,255,0.1)" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-width="1.5" d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z"/>
          </svg>
        </div>
        <div class="lock-ov">
          <div class="lock-circle">
            <svg width="14" height="14" fill="none" stroke="white" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-width="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"/>
            </svg>
          </div>
          <div class="lock-txt">Login untuk interaksi</div>
        </div>
      </div>
    <?php endfor; ?>
  </div>
</div>

<div class="cta-banner">
  <h2>Siap berbagi karya?</h2>
  <p>Bergabung dengan ribuan fotografer dan mulai abadikan momen terbaikmu.</p>
  <a href="<?= BASE_URL ?>/register.php" class="hbtn-main">Daftar Gratis</a>
</div>

<?php require_once 'includes/footer.php'; ?>
