<?php
require_once 'includes/config.php';
require_once 'includes/db.php';
require_once 'includes/auth.php';

if (isLoggedIn()) redirect('home.php');

$error = '';

if (isPost()) {
    verifyCsrf();
    $login    = trim($_POST['Username'] ?? '');
    $password = $_POST['Password'] ?? '';

    if (empty($login) || empty($password)) {
        $error = 'Username/email dan password wajib diisi.';
    } else {
        $user = queryOne(
            "SELECT * FROM user WHERE Username=? OR Email=? LIMIT 1",
            [$login, $login], 'ss'
        );
        if ($user && password_verify($password, $user['Password'])) {
            $_SESSION['user_id']      = $user['UserID'];
            $_SESSION['username']     = $user['Username'];
            $_SESSION['nama_lengkap'] = $user['NamaLengkap'];
            $_SESSION['email']        = $user['Email'];
            clearOld();
            redirect('home.php');
        } else {
            $error = 'Username/email atau password salah.';
        }
    }
}

$pageTitle = 'Masuk — Lensa Bercerita';
require_once 'includes/header.php';
?>

<div class="auth-wrap">
  <div class="auth-vis">
    <div class="auth-vis-logo">
      <img src="<?= BASE_URL ?>/assets/images/logo.png" alt="Logo"
           style="width:56px;height:56px;object-fit:contain;filter:invert(1)">
    </div>
    <div>
      <div class="auth-vis-quote">"Setiap foto adalah sebuah sertifikat kehadiran."</div>
      <div class="auth-vis-cite">— Susan Sontag</div>
    </div>
  </div>
  <div class="auth-form-side">
    <div class="auth-box">
      <div class="auth-ttl">Selamat Datang</div>
      <div class="auth-sub">Masuk untuk melanjutkan ke Lensa Bercerita</div>

      <?php if ($error): ?>
        <div class="alert-error"><?= e($error) ?></div>
      <?php endif; ?>

      <form method="POST">
        <input type="hidden" name="csrf_token" value="<?= csrf() ?>">
        <div class="fg">
          <label class="lbl">Username atau Email</label>
          <input class="finput" type="text" name="Username" value="<?= old('Username') ?>" placeholder="username / email" required autofocus>
        </div>
        <div class="fg">
          <label class="lbl">Password</label>
          <div style="position:relative">
            <input class="finput" type="password" name="Password" id="inp-password" placeholder="••••••" required style="padding-right:38px">
            <button type="button"
              onmousedown="showPass('inp-password')" onmouseup="hidePass('inp-password')"
              onmouseleave="hidePass('inp-password')" ontouchstart="showPass('inp-password')"
              ontouchend="hidePass('inp-password')"
              style="position:absolute;right:10px;top:50%;transform:translateY(-50%);background:none;border:none;cursor:pointer;color:var(--wh3);padding:0;display:flex;align-items:center">
              <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/>
                <path stroke-linecap="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/>
              </svg>
            </button>
          </div>
        </div>
        <button type="submit" class="auth-btn">Masuk</button>
      </form>
      <div class="auth-switch">Belum punya akun? <a href="<?= BASE_URL ?>/register.php">Daftar sekarang</a></div>
    </div>
  </div>
</div>

<?php require_once 'includes/footer.php'; ?>
