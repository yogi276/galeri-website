<?php
require_once 'includes/config.php';
require_once 'includes/db.php';
require_once 'includes/auth.php';

if (isLoggedIn()) redirect('home.php');

$error = '';

if (isPost()) {
    verifyCsrf();
    $nama     = trim($_POST['NamaLengkap'] ?? '');
    $username = trim($_POST['Username'] ?? '');
    $email    = trim($_POST['Email'] ?? '');
    $pass     = $_POST['Password'] ?? '';
    $pass2    = $_POST['Password_confirmation'] ?? '';

    setOld(['NamaLengkap'=>$nama,'Username'=>$username,'Email'=>$email]);

    if (empty($nama)||empty($username)||empty($email)||empty($pass)) {
        $error = 'Semua field wajib diisi.';
    } elseif (strlen($pass) < 6) {
        $error = 'Password minimal 6 karakter.';
    } elseif ($pass !== $pass2) {
        $error = 'Konfirmasi password tidak cocok.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Format email tidak valid.';
    } else {
        $existing = queryOne("SELECT UserID FROM user WHERE Username=? OR Email=?", [$username,$email], 'ss');
        if ($existing) {
            $error = 'Username atau email sudah digunakan.';
        } else {
            $hash = password_hash($pass, PASSWORD_BCRYPT);
            $id = insert(
                "INSERT INTO user (Username,Password,Email,NamaLengkap) VALUES (?,?,?,?)",
                [$username,$hash,$email,$nama], 'ssss'
            );
            $_SESSION['user_id']      = $id;
            $_SESSION['username']     = $username;
            $_SESSION['nama_lengkap'] = $nama;
            $_SESSION['email']        = $email;
            clearOld();
            redirect('home.php');
        }
    }
}

$pageTitle = 'Daftar — Lensa Bercerita';
require_once 'includes/header.php';
?>

<div class="auth-wrap">
  <div class="auth-vis">
    <div class="auth-vis-logo">
      <img src="<?= BASE_URL ?>/assets/images/logo.png" alt="Logo"
           style="width:56px;height:56px;object-fit:contain;filter:invert(1)">
    </div>
    <div>
      <div class="auth-vis-quote">"Fotografi adalah seni observasi."</div>
      <div class="auth-vis-cite">— Elliott Erwitt</div>
    </div>
  </div>
  <div class="auth-form-side">
    <div class="auth-box">
      <div class="auth-ttl">Buat Akun</div>
      <div class="auth-sub">Bergabung dengan komunitas fotografer Indonesia</div>

      <?php if ($error): ?>
        <div class="alert-error"><?= e($error) ?></div>
      <?php endif; ?>

      <form method="POST">
        <input type="hidden" name="csrf_token" value="<?= csrf() ?>">
        <div class="fg">
          <label class="lbl">Nama Lengkap</label>
          <input class="finput" type="text" name="NamaLengkap" value="<?= old('NamaLengkap') ?>" placeholder="Nama lengkap" required>
        </div>
        <div class="fg">
          <label class="lbl">Username</label>
          <input class="finput" type="text" name="Username" value="<?= old('Username') ?>" placeholder="username unik" required>
        </div>
        <div class="fg">
          <label class="lbl">Email</label>
          <input class="finput" type="email" name="Email" value="<?= old('Email') ?>" placeholder="email@kamu.com" required>
        </div>
        <div class="fg">
          <label class="lbl">Password</label>
          <div style="position:relative">
            <input class="finput" type="password" name="Password" id="inp-pass1" placeholder="Min. 6 karakter" required style="padding-right:38px">
            <button type="button" onmousedown="showPass('inp-pass1')" onmouseup="hidePass('inp-pass1')"
              onmouseleave="hidePass('inp-pass1')" ontouchstart="showPass('inp-pass1')" ontouchend="hidePass('inp-pass1')"
              style="position:absolute;right:10px;top:50%;transform:translateY(-50%);background:none;border:none;cursor:pointer;color:var(--wh3);padding:0;display:flex;align-items:center">
              <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/>
                <path stroke-linecap="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/>
              </svg>
            </button>
          </div>
        </div>
        <div class="fg">
          <label class="lbl">Konfirmasi Password</label>
          <div style="position:relative">
            <input class="finput" type="password" name="Password_confirmation" id="inp-pass2" placeholder="Ulangi password" required style="padding-right:38px">
            <button type="button" onmousedown="showPass('inp-pass2')" onmouseup="hidePass('inp-pass2')"
              onmouseleave="hidePass('inp-pass2')" ontouchstart="showPass('inp-pass2')" ontouchend="hidePass('inp-pass2')"
              style="position:absolute;right:10px;top:50%;transform:translateY(-50%);background:none;border:none;cursor:pointer;color:var(--wh3);padding:0;display:flex;align-items:center">
              <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/>
                <path stroke-linecap="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/>
              </svg>
            </button>
          </div>
        </div>
        <button type="submit" class="auth-btn">Daftar</button>
      </form>
      <div class="auth-switch">Sudah punya akun? <a href="<?= BASE_URL ?>/login.php">Masuk</a></div>
    </div>
  </div>
</div>

<?php require_once 'includes/footer.php'; ?>
