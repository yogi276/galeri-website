<?php
require_once 'includes/config.php';
require_once 'includes/db.php';
require_once 'includes/auth.php';

requireLogin();
$user = currentUser();
$uid  = $user['UserID'];
$error = '';

if (isPost()) {
    verifyCsrf();
    $judul  = trim($_POST['JudulFoto'] ?? '');
    $desk   = trim($_POST['DeskripsiFoto'] ?? '');
    $albumId = (int)($_POST['AlbumID'] ?? 0) ?: null;
    $akses  = $_POST['Akses'] ?? 'publik';

    if (empty($judul)) {
        $error = 'Judul foto wajib diisi.';
    } elseif (empty($_FILES['foto']['name'])) {
        $error = 'File foto wajib diunggah.';
    } else {
        $upload = uploadFoto($_FILES['foto']);
        if (isset($upload['error'])) {
            $error = $upload['error'];
        } else {
            insert(
                "INSERT INTO foto (JudulFoto,DeskripsiFoto,TanggalUnggah,LokasiFile,AlbumID,UserID,Akses)
                 VALUES (?,?,CURDATE(),?,?,?,?)",
                [$judul,$desk,$upload['filename'],$albumId,$uid,$akses], 'sssiis'
            );
            flash('success', 'Foto berhasil diunggah!');
            redirect('dashboard.php');
        }
    }
}

$albums = queryAll("SELECT AlbumID, NamaAlbum FROM album WHERE UserID=? ORDER BY NamaAlbum", [$uid], 'i');
$pageTitle = 'Unggah Foto — Lensa Bercerita';
require_once 'includes/header.php';
?>

<div class="form-wrap">
  <div class="form-header">
    <h2 class="form-title">Unggah Foto</h2>
    <a href="<?= BASE_URL ?>/dashboard.php" class="form-back">← Kembali</a>
  </div>

  <?php if ($error): ?>
    <div class="alert-error"><?= e($error) ?></div>
  <?php endif; ?>

  <form method="POST" enctype="multipart/form-data">
    <input type="hidden" name="csrf_token" value="<?= csrf() ?>">

    <div class="drop-zone" id="drop-zone" onclick="document.getElementById('file-input').click()">
      <div class="drop-zone-inner" id="drop-preview">
        <svg width="40" height="40" fill="none" stroke="currentColor" viewBox="0 0 24 24" style="opacity:.3;margin-bottom:10px">
          <path stroke-linecap="round" stroke-width="1.5" d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z"/>
          <circle cx="12" cy="13" r="3" stroke-width="1.5"/>
        </svg>
        <p style="font-family:sans-serif;font-size:12px;color:var(--wh3)">Klik atau seret foto ke sini</p>
        <p style="font-family:sans-serif;font-size:10px;color:var(--bk4);margin-top:4px">JPG, PNG, WEBP · Maks. 10MB</p>
      </div>
      <input type="file" id="file-input" name="foto" accept="image/*" style="display:none" required>
    </div>

    <div class="fg">
      <label class="lbl">Judul Foto *</label>
      <input class="finput" type="text" name="JudulFoto" value="<?= old('JudulFoto') ?>" placeholder="Judul foto..." required>
    </div>
    <div class="fg">
      <label class="lbl">Deskripsi</label>
      <textarea class="finput" name="DeskripsiFoto" rows="3" placeholder="Ceritakan foto ini..."><?= old('DeskripsiFoto') ?></textarea>
    </div>
    <div class="two-col">
      <div class="fg">
        <label class="lbl">Album</label>
        <select class="finput" name="AlbumID" style="cursor:pointer">
          <option value="">-- Tanpa Album --</option>
          <?php foreach ($albums as $alb): ?>
            <option value="<?= $alb['AlbumID'] ?>"><?= e($alb['NamaAlbum']) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="fg">
        <label class="lbl">Akses *</label>
        <select class="finput" name="Akses" style="cursor:pointer">
          <option value="publik">Publik</option>
          <option value="private">Private</option>
        </select>
      </div>
    </div>
    <div style="display:flex;gap:10px;margin-top:8px">
      <button type="submit" class="auth-btn">Unggah Foto</button>
      <a href="<?= BASE_URL ?>/dashboard.php" class="btn-sm btn-o" style="padding:9px 20px;text-decoration:none;border-radius:6px;font-size:13px;font-family:sans-serif">Batal</a>
    </div>
  </form>
</div>

<?php
$extraJs = <<<JS
const dz=document.getElementById('drop-zone');
const fi=document.getElementById('file-input');
const preview=document.getElementById('drop-preview');
fi.addEventListener('change',()=>showPreview(fi.files[0]));
dz.addEventListener('dragover',e=>{e.preventDefault();dz.classList.add('dragover');});
dz.addEventListener('dragleave',()=>dz.classList.remove('dragover'));
dz.addEventListener('drop',e=>{
  e.preventDefault();dz.classList.remove('dragover');
  const file=e.dataTransfer.files[0];
  if(file){const dt=new DataTransfer();dt.items.add(file);fi.files=dt.files;showPreview(file);}
});
function showPreview(file){
  if(!file)return;
  const reader=new FileReader();
  reader.onload=e=>{
    preview.innerHTML=`<img src="\${e.target.result}" style="max-height:200px;border-radius:6px;object-fit:contain">
      <p style="font-family:sans-serif;font-size:11px;color:var(--wh3);margin-top:8px">\${file.name}</p>`;
  };
  reader.readAsDataURL(file);
}
JS;
require_once 'includes/footer.php';
?>
